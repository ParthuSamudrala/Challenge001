function call(obj,key) { 
	var keys = key.split('/');
	console.log(keys);
	var value;
	var temp = obj;
	for (var item of keys) {
		value =temp[item] ? temp[item]:value;
		temp = value;
	}
	console.log(temp);
}

// call(obj, 'a/b/c')