#ret_metad.sh

#!/bin/bash

output=$metadata.json

curl --silent http://169.254.169.254/latest/dynamic/instance-identity/document

cat $output
